//
//  InitPluggable.h
//  background_locator
//
//  Created by Mehdok on 6/7/21.
//

#import <Foundation/Foundation.h>
#import "Pluggable.h"

NS_ASSUME_NONNULL_BEGIN

@interface InitPluggable : NSObject<Pluggable>

@end

NS_ASSUME_NONNULL_END
