
  String getHTMLEmail(String name, String email, String code, String school){
    return """
                            <!DOCTYPE html>
<td align="center" valign="top"
    style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
    <center style="min-width:680px;width:100%">
        <table align="center"
            style="Margin:0 auto;background:#fff;background-color:#f5f8fa;border-collapse:collapse;border-spacing:0;float:none;margin:0 auto;padding:0;text-align:center;vertical-align:top;width:680px">
            <tbody>
                <tr style="padding:0;text-align:left;vertical-align:top">
                    <td
                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">

                        <table
                            style="background-color:#f5f8fa;border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%">
                            <tbody>
                                <tr style="padding:0;text-align:left;vertical-align:top">

                                    <th valign="middle"
                                        style="Margin:0 auto;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0 auto;padding:1em 0!important;padding-bottom:0;padding-left:40px;padding-right:20px;text-align:left;width:300px">
                                        <table
                                            style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%">
                                            <tbody>
                                                <tr style="padding:0;text-align:left;vertical-align:top">
                                                    <th
                                                        style="Margin:0;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0 15px;text-align:left">
                                                        <a
                                                        style="Margin:0;color:#1da1f2;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-weight:700;line-height:1.2em;margin:0;padding:0;text-align:left;text-decoration:none"><img
                                                            alt="Sunny Connect" height="40",
                                                            src="https://firebasestorage.googleapis.com/v0/b/sunny-connect.appspot.com/o/logo.png?alt=media&token=eb8991cb-d42a-4463-9eb0-ca12edd48c25"
                                                            style="border:none;clear:both;display:block;float:left;max-height:30px;max-width:100%;outline:0;padding:1em 0!important;text-align:left;text-decoration:none;width:auto"
                                                            class="CToWUd"></a> </th>
                                                        <th
                                                            style="Margin:0;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0 15px;text-align:left">
                                                            <a
                                                            style="Margin:0;color:#1da1f2;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-weight:700;line-height:1.2em;margin:0;padding:0;text-align:left;text-decoration:none">
                                                        <h2>HAR at Sunny Connect</h2>
                                                        </a> </th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <table
            style="Margin:0 auto;border-collapse:collapse;border-spacing:0;float:none;margin:0 auto;padding:0;text-align:center;vertical-align:top">
            <tbody>
                <tr style="padding:0;text-align:left;vertical-align:top">
                    <td height="10px"
                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:10px;font-weight:400;line-height:10px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                        &nbsp;</td>
                </tr>
            </tbody>
        </table>
        <table align="center"
            style="Margin:0 auto;background:#fff;border-collapse:collapse;border-radius:5px;border-spacing:0;float:none;margin:0 auto;padding:0;text-align:center;vertical-align:top;width:680px">
            <tbody>
                <tr style="padding:0;text-align:left;vertical-align:top">
                    <td
                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                        <table
                            style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top">
                            <tbody>
                                <tr style="padding:0;text-align:left;vertical-align:top">
                                    <td height="40px"
                                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:40px;font-weight:400;line-height:40px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                                        &nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                        <table
                            style="border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%">
                            <tbody>
                                <tr style="padding:0;text-align:left;vertical-align:top">
                                    <th
                                        style="Margin:0 auto;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0 auto;padding:0;padding-bottom:0;padding-left:40px;padding-right:40px;text-align:left;width:640px">
                                        <table
                                            style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%">
                                            <tbody>
                                                <tr style="padding:0;text-align:left;vertical-align:top">
                                                    <th
                                                        style="Margin:0;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left">
                                                        <h2
                                                            style="Margin:0;Margin-bottom:1em;color:#14171a;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:24px;font-weight:700;line-height:1.2em;margin:0;margin-bottom:1em;padding:0;text-align:left;word-wrap:normal">
                                                            Welcome ${name}, to the Sunny Connect Technologies</h2>
                                                        <p
                                                            style="Margin:0;Margin-bottom:1em;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;margin-bottom:1em;padding:0;text-align:left">
                                                            Thanks for joining Sunny Connect.</p>
                                                        <p
                                                            style="Margin:0;Margin-bottom:1em;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;margin-bottom:1em;padding:0;text-align:left">
                                                            You are registered as Teacher at School $school, with email \'$email\'.</p>
                                                        <p
                                                            style="Margin:0;Margin-bottom:1em;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;margin-bottom:1em;padding:0;text-align:left">
                                                            Password is given below.</p>
                                                        <table
                                                            style="Margin:2em 0;border-collapse:collapse;border-spacing:0;margin:2em 0;padding:0;text-align:left;vertical-align:top;width:auto!important">
                                                            <tbody>
                                                                <tr
                                                                    style="padding:0;text-align:left;vertical-align:top">
                                                                    <td
                                                                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                                                                        <table
                                                                            style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%">
                                                                            <tbody>
                                                                                <tr
                                                                                    style="padding:0;text-align:left;vertical-align:top">
                                                                                    <td
                                                                                        style="Margin:0;background:#ffad1f;border:none;border-collapse:collapse!important;border-radius:3px;color:#fff;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                                                                                        <a 
                                                                                            style="Margin:0;border:0 solid #ffad1f;border-radius:3px;color:#fff;display:inline-block;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.2em;margin:0;padding:.5em 1em;text-align:left;text-decoration:none"
                                                                                            target="_blank">
                                                                                            Password : $code</a></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <p
                                                            style="Margin:0;Margin-bottom:1em;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;margin-bottom:1em;padding:0;text-align:left">
                                                            Thanks!<br>Regards : Admin Sunny Connect</p>
                                                    </th>
                                                    <th
                                                        style="Margin:0;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;margin:0;padding:0!important;text-align:left;width:0">
                                                    </th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                        <table
                            style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top">
                            <tbody>
                                <tr style="padding:0;text-align:left;vertical-align:top">
                                    <td height="40px"
                                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:40px;font-weight:400;line-height:40px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                                        &nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <table
            style="Margin:0 auto;border-collapse:collapse;border-spacing:0;float:none;margin:0 auto;padding:0;text-align:center;vertical-align:top">
            <tbody>
                <tr style="padding:0;text-align:left;vertical-align:top">
                    <td height="40px"
                        style="Margin:0;border-collapse:collapse!important;color:#657786;font-family:'Helvetica Neue LT','Helvetica Neue',Helvetica,Arial,sans-serif;font-size:40px;font-weight:400;line-height:40px;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">
                        &nbsp;</td>
                </tr>
            </tbody>
        </table>
        
    </center>
</td>
                            """;
  }
