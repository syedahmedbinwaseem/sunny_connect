


import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get register_new_school => 'Wants to register new school?';

  @override
  String get sign_in => 'Signin';

  @override
  String get username => 'User name';

  @override
  String get school_name => 'Name of school';

  @override
  String get password => 'Password';

  @override
  String get forgot => 'Forgot Password?';

  @override
  String get dont_have_account => 'Don’t have an aacount? ';

  @override
  String get email => 'Email';

  @override
  String get confirm_password => 'Confirm Password';

  @override
  String get confirm_email => 'Confirm Email';

  @override
  String get already_have_account => 'Already have an account? ';

  @override
  String get signin => 'Signin';

  @override
  String get signup => 'Signup';

  @override
  String get create_new_account => 'Create new account';

  @override
  String get school => 'School';

  @override
  String get teacher => 'Teacher';

  @override
  String get student => 'Student';

  @override
  String get students => 'Students';

  @override
  String get teachers => 'Teachers';

  @override
  String get teacher_newpost_alert => 'added new post';

  @override
  String get your_email => 'Your email';

  @override
  String get comment________________________________________Registration_____________________________________________ => '*****************';

  @override
  String get create_student => 'Create A New Account';

  @override
  String get register_new_school_title => 'Register New School Account';

  @override
  String get phone_number => 'Phone number';

  @override
  String get city => 'City';

  @override
  String get country => 'Country';

  @override
  String get register => 'Register';

  @override
  String get comment________________________________________Reset_____________________________________________ => '*****************';

  @override
  String get reset_password => 'Reset Password';

  @override
  String get submit => 'Submit';

  @override
  String get reset_link_sent_title => 'Reset Password link sent!';

  @override
  String get reset_link_text => 'Password reset link sent on your email';

  @override
  String get ok => 'Okay';

  @override
  String get too_many_request => 'You are trying too often. Please try again later';

  @override
  String get operation_failed => 'Operation failed. Try again later';

  @override
  String get comment________________________________________Home_____________________________________________ => '*****************';

  @override
  String get home => 'Home';

  @override
  String get classrooms => 'Classrooms';

  @override
  String get no_class_joined_msg => 'You have not joined any class!';

  @override
  String get are_you_sure => 'Are you sure?';

  @override
  String get logout_msg => 'Do you want to logout?';

  @override
  String get yes => 'Yes';

  @override
  String get cancel => 'Cancel';

  @override
  String get comment________________________________________Student_____________________________________________ => '*****************';

  @override
  String get add_classroom => 'Add classroom';

  @override
  String get class_name => 'Class name';

  @override
  String get class_code => 'Class code';

  @override
  String get add => 'Add';

  @override
  String get download => 'Download';

  @override
  String get comment________________________________________AdminSchool_____________________________________________ => '*****************';

  @override
  String get add_teacher => 'Add Teacher';

  @override
  String get teacher_name => 'Teacher name';

  @override
  String get teacher_email => 'Teacher email';

  @override
  String get teacher_department => 'Teacher department';

  @override
  String get about_teacher => 'About teacher';

  @override
  String get member_since => 'Member since';

  @override
  String get teacher_added_title => 'New Teacher Added';

  @override
  String get teacher_added_text => 'Kindly ask your teacher to check his email for Account credentials!';

  @override
  String get comment________________________________________Post_____________________________________________ => '*****************';

  @override
  String get post_text => 'Add your post here, it will be shared with your students!';

  @override
  String get post_appbar_text => 'Add New Post';

  @override
  String get post => 'Post';

  @override
  String get no_post_text => 'No post added yet!';

  @override
  String get postfield_labeltext => 'Announce anything to your class!';

  @override
  String get post_published_title => 'New Post published';

  @override
  String get post_published_text => 'Your post has been published successfully!';

  @override
  String get comment________________________________________Class_____________________________________________ => '*****************';

  @override
  String get add_class_appbar => 'Add New Class';

  @override
  String get add_class_text => 'Add your class here, and share Class Name and Code with your friends to join!';

  @override
  String get description => 'description';

  @override
  String get class_added_title => 'New Class Added';

  @override
  String get class_added_text => 'Kindly share Class name and Class code with your students to join!';
}
