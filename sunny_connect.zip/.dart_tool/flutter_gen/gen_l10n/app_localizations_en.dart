


import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get register_new_school => 'Wants to register new school?';

  @override
  String get sign_in => 'Signin';

  @override
  String get username => 'User name';

  @override
  String get school_name => 'Name of school';

  @override
  String get password => 'Password';

  @override
  String get forgot => 'Forgot Password?';

  @override
  String get dont_have_account => 'Don’t have an aacount ? Sign up';

  @override
  String get email => 'Email';

  @override
  String get confirm_password => 'Confirm Password';

  @override
  String get confirm_email => 'Confirm Email';

  @override
  String get already_have_account => 'Already have an account? Login';

  @override
  String get signin => 'Signin';

  @override
  String get signup => 'Signup';

  @override
  String get create_new_account => 'Create new account';

  @override
  String get school => 'School';

  @override
  String get teacher => 'Teacher';

  @override
  String get student => 'Student';

  @override
  String get students => 'Students';

  @override
  String get classrooms => 'Classrooms';

  @override
  String get add_classroom => 'Add classroom';

  @override
  String get teachers => 'Teachers';

  @override
  String get add_teacher => 'Add Teacher';

  @override
  String get teacher_newpost_alert => 'added new post';

  @override
  String get your_email => 'Your email';
}
