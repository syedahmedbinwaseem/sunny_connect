


import 'app_localizations.dart';

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get register_new_school => 'تريد تسجيل مدرسة جديدة؟';

  @override
  String get sign_in => 'الدخول';

  @override
  String get username => 'اسم المستخدم';

  @override
  String get school_name => 'اسم المدرسة';

  @override
  String get password => 'كلمة السر';

  @override
  String get forgot => 'نسيت كلمة السر';

  @override
  String get dont_have_account => 'عندي حساب؟ إنشاء حساب';

  @override
  String get email => 'بريدك الإلكتروني';

  @override
  String get confirm_password => 'تأكيد كلمة المرور';

  @override
  String get confirm_email => 'تأكيد عنوان البريد';

  @override
  String get already_have_account => 'لديك حساب؟';

  @override
  String get signin => 'الدخول';

  @override
  String get signup => 'إنشاء حساب';

  @override
  String get create_new_account => 'إنشاء حساب جديد';

  @override
  String get school => 'المؤسسة';

  @override
  String get teacher => 'أستاذ';

  @override
  String get student => 'تلميذ';

  @override
  String get students => 'التلاميذ';

  @override
  String get classrooms => 'الأقسام';

  @override
  String get add_classroom => 'إضافة قسم جديد';

  @override
  String get teachers => 'الأساتذة';

  @override
  String get add_teacher => 'إضافة أستاذ جديد';

  @override
  String get teacher_newpost_alert => '(الأستاذ) قام بنشر منشور جديد في 30/ 10';

  @override
  String get your_email => 'بريدك الإلكتروني';
}
