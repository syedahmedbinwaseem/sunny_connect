
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sunny_connect/modals/app_class.dart';
import 'package:sunny_connect/modals/users/current_app_user.dart';
import 'package:sunny_connect/screens/teacher_specific/add_class.dart';
import 'package:sunny_connect/screens/teacher_specific/teacher_profile.dart';
import 'package:sunny_connect/utils/app_navigator.dart';
import 'package:sunny_connect/utils/widgets.dart';
import 'package:sunny_connect/utils/colors.dart';

import '../classroom_feeds.dart';

class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({Key key}) : super(key: key);

  @override
  _TeacherDashboardState createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        backgroundColor: primaryBlue,
        onPressed: (){
          AppNavigator.push(context, const AddNewClass());
        },
      ),
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: Column(
            children: [
              topContainer(height, width),
              const SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: StreamBuilder<QuerySnapshot>(
                  stream: AppClass.streamAppClassWithTeacher(CurrentAppUser.currentUserData.uid),
                  builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.hasError) {
                      return const Center(child: Text('Something went wrong'));
                    }

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator(semanticsLabel: "Loading"));
                    }

                    if(snapshot.data.docs.isEmpty){
                      return const Center(child: Text('You do not have any class!', style: TextStyle(fontStyle: FontStyle.italic,)));
                    }

                    return Column(
                      children: snapshot.data.docs.map((DocumentSnapshot document) {
                      Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                        return classCard(MediaQuery.of(context).size.height, MediaQuery.of(context).size.width, data);
                      }).toList(),
                    );
                  },
                ),
              ),
            ],
          )
        ),
      ),
    );
  }

  Widget classCard(double height, double width, Map<String, dynamic> data) {
    AppClass appClass = AppClass.fromMap(data);
    return GestureDetector(
      onTap: (){
        AppNavigator.push(context, ClassRoomScreen(appClass: appClass,));
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Material(
          elevation: 2,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            padding: const EdgeInsets.all(10),
            width: width,
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${appClass.name} ',
                      style: TextStyle(
                          fontSize: 16,
                          color: primaryBlue,
                          fontWeight: FontWeight.bold),
                    ),
                    // const Spacer(),
                    Text(
                      '${DateFormat('dd MMM, yyyy').format(appClass.createdAt)} ',
                      style: TextStyle(
                        fontSize: 12,
                        color: primaryBlue,
                      ),
                    ),
                  ],
                ),
                
                Text('#${appClass.code}', style: TextStyle(color: primaryBlue)),
                const SizedBox(height: 5),
                Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    '${appClass.description??'No-Description added!'} ',
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.black87,
                    ),
                  ),
                ),
                const SizedBox(height: 5),
                
                
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget topContainer(double height, double width) {
    return SafeArea(
      child: Container(
        height: height * 0.3,
        width: width,
        color: primaryBlue,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                height: 30,
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: (){
                    Utilities.showLogoutDialog(context);
                  },
                  child: const Icon(Icons.logout, color: Colors.white)),
              ),
            ),
            GestureDetector(
              onTap: (){
                AppNavigator.push(context, const TeacherProfile());
              },
              child: Column(
                children: [
                  SizedBox(
                    height: height * 0.3 / 2.5,
                    width: height * 0.3 / 2.5,
                    child: ClipRRect(
                          borderRadius: BorderRadius.circular(1000),
                          child: CachedNetworkImage(
                              imageUrl: CurrentAppUser.currentUserData.photoUrl,
                              progressIndicatorBuilder: (context, url, downloadProgress) => 
                                      CircularProgressIndicator(value: downloadProgress.progress),
                              errorWidget: (context, url, error) => const Icon(Icons.person, size: 42, color: Colors.white),
                              fit: BoxFit.cover,
                          ),
                        ),
                  ),
                  const SizedBox(height: 15),
                  
                  Text(
                    '${CurrentAppUser.currentUserData.name}(Teacher)',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.email_outlined, color: Colors.white),
                      const SizedBox(width: 5),
                      Text(
                        CurrentAppUser.currentUserData.email.toString(),
                        style: const TextStyle(
                            color: Colors.white, fontSize: 17),
                      ),
                    ],
                  ),
            ],
            ),
            )
          ],
        ),
      ),
    );
  }


  Widget bottomLiveCard(double height, double width, String name) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(15)),
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: TextStyle(
                  fontSize: 16,
                  color: primaryBlue,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'LIVE',
              style: TextStyle(color: Colors.red, fontSize: 12),
            ),
            const SizedBox(height: 5),
            Container(
              height: width * 0.5,
              width: width,
              decoration: BoxDecoration(border: Border.all(color: Colors.red)),
            )
          ],
        ),
      ),
    );
  }

}
