class DatabaseStrings{
  static String STUDENT_COL = 'student';
  static String TEACHER_COL = 'teacher';
  static String SCHOOL_COL = 'school';
  static String CLASS_COL = 'classes';
  static String POST_COL = 'posts';

}