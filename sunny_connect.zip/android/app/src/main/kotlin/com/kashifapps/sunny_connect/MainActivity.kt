package com.kashifapps.sunny_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
