


import 'app_localizations.dart';

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get register_new_school => 'تريد تسجيل مدرسة جديدة؟';

  @override
  String get sign_in => 'الدخول';

  @override
  String get username => 'اسم المستخدم';

  @override
  String get school_name => 'اسم المدرسة';

  @override
  String get password => 'كلمة السر';

  @override
  String get forgot => 'نسيت كلمة السر';

  @override
  String get dont_have_account => 'عندي حساب؟ ';

  @override
  String get email => 'بريدك الإلكتروني';

  @override
  String get confirm_password => 'تأكيد كلمة المرور';

  @override
  String get confirm_email => 'تأكيد عنوان البريد';

  @override
  String get already_have_account => 'لديك حساب؟';

  @override
  String get signin => 'الدخول';

  @override
  String get signup => 'إنشاء حساب';

  @override
  String get create_new_account => 'إنشاء حساب جديد';

  @override
  String get school => 'المؤسسة';

  @override
  String get teacher => 'الأستاذ';

  @override
  String get student => 'التلميذ';

  @override
  String get students => 'التلاميذ';

  @override
  String get teachers => 'الأساتذة';

  @override
  String get teacher_newpost_alert => '(الأستاذ) قام بنشر منشور جديد في';

  @override
  String get your_email => 'بريدك الإلكتروني';

  @override
  String get comment________________________________________Registration_____________________________________________ => '*****************';

  @override
  String get create_student => 'انشاء حساب جديد';

  @override
  String get register_new_school_title => 'تسجيل حساب مدرسة جديد';

  @override
  String get phone_number => 'رقم الهاتف';

  @override
  String get city => 'مدينة';

  @override
  String get country => 'دولة';

  @override
  String get register => 'تسجيل';

  @override
  String get comment________________________________________Reset_____________________________________________ => '*****************';

  @override
  String get reset_password => 'إعادة تعيين كلمة المرور  ';

  @override
  String get submit => 'يقدم';

  @override
  String get reset_link_sent_title => 'تم إرسال رابط إعادة تعيين كلمة المرور!';

  @override
  String get reset_link_text => 'تم إرسال رابط إعادة تعيين كلمة المرور على بريدك الإلكتروني';

  @override
  String get ok => 'تمام';

  @override
  String get too_many_request => 'انت تحاول كثيرا الرجاء معاودة المحاولة في وقت لاحق';

  @override
  String get operation_failed => 'فشلت العملية. حاول مرة أخرى في وقت لاحق';

  @override
  String get comment________________________________________Home_____________________________________________ => '*****************';

  @override
  String get home => 'الصفحة الرئيسية';

  @override
  String get classrooms => 'الأقسام';

  @override
  String get no_class_joined_msg => 'أنت لم تنضم إلى أي فصل!';

  @override
  String get are_you_sure => 'هل أنت متأكد؟';

  @override
  String get logout_msg => 'هل ترغب بالخروج؟';

  @override
  String get yes => 'نعم';

  @override
  String get cancel => 'يلغي';

  @override
  String get comment________________________________________Student_____________________________________________ => '*****************';

  @override
  String get add_classroom => 'إضافة قسم جديد';

  @override
  String get class_name => 'اسم الفصل';

  @override
  String get class_code => 'كود الفصل';

  @override
  String get add => 'يضيف';

  @override
  String get download => 'تحميل';

  @override
  String get comment________________________________________AdminSchool_____________________________________________ => '*****************';

  @override
  String get add_teacher => 'إضافة أستاذ جديد';

  @override
  String get teacher_name => 'اسم المعلم';

  @override
  String get teacher_email => 'البريد الإلكتروني للمعلم';

  @override
  String get teacher_department => 'قسم المعلم';

  @override
  String get about_teacher => 'عن المعلم';

  @override
  String get member_since => 'عضو منذ';

  @override
  String get teacher_added_title => 'تمت اضافة أستاذ جديد';

  @override
  String get teacher_added_text => 'سوف يتوصل الأستاذ ب الرقم السري في بريده الالكتروني.';

  @override
  String get comment________________________________________Post_____________________________________________ => '*****************';

  @override
  String get post_text => 'أضف منشورك هنا ، وسيتم مشاركته مع طلابك!';

  @override
  String get post_appbar_text => 'أضف منشور جديد';

  @override
  String get post => 'بريد';

  @override
  String get no_post_text => 'لم تتم اضافة أي منشور حتى الآن';

  @override
  String get postfield_labeltext => 'أعلن أي شيء لفصلك!';

  @override
  String get post_published_title => 'تم نشر منشور جديد';

  @override
  String get post_published_text => 'تم نشر رسالتك بنجاح!';

  @override
  String get comment________________________________________Class_____________________________________________ => '*****************';

  @override
  String get add_class_appbar => 'إضافة فصل جديد';

  @override
  String get add_class_text => 'أضف فصلك هنا ، وشارك اسم الفصل والرمز مع أصدقائك للانضمام!';

  @override
  String get description => 'وصف';

  @override
  String get class_added_title => 'اضافة قسم جديد';

  @override
  String get class_added_text => 'يرجى مشاركة اسم الفصل ورمز الفصل مع طلابك للانضمام!';

  @override
  String get comment________________________________________Nofitications_____________________________________________ => '*****************';

  @override
  String get post_new_announcement_title => 'نشر إعلانًا جديدًا في';
}
