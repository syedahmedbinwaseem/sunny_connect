
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations returned
/// by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// localizationDelegates list, and the locales they support in the app's
/// supportedLocales list. For example:
///
/// ```
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @register_new_school.
  ///
  /// In en, this message translates to:
  /// **'Wants to register new school?'**
  String get register_new_school;

  /// No description provided for @sign_in.
  ///
  /// In en, this message translates to:
  /// **'Signin'**
  String get sign_in;

  /// No description provided for @username.
  ///
  /// In en, this message translates to:
  /// **'User name'**
  String get username;

  /// No description provided for @school_name.
  ///
  /// In en, this message translates to:
  /// **'Name of school'**
  String get school_name;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @forgot.
  ///
  /// In en, this message translates to:
  /// **'Forgot Password?'**
  String get forgot;

  /// No description provided for @dont_have_account.
  ///
  /// In en, this message translates to:
  /// **'Don’t have an aacount? '**
  String get dont_have_account;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @confirm_password.
  ///
  /// In en, this message translates to:
  /// **'Confirm Password'**
  String get confirm_password;

  /// No description provided for @confirm_email.
  ///
  /// In en, this message translates to:
  /// **'Confirm Email'**
  String get confirm_email;

  /// No description provided for @already_have_account.
  ///
  /// In en, this message translates to:
  /// **'Already have an account? '**
  String get already_have_account;

  /// No description provided for @signin.
  ///
  /// In en, this message translates to:
  /// **'Signin'**
  String get signin;

  /// No description provided for @signup.
  ///
  /// In en, this message translates to:
  /// **'Signup'**
  String get signup;

  /// No description provided for @create_new_account.
  ///
  /// In en, this message translates to:
  /// **'Create new account'**
  String get create_new_account;

  /// No description provided for @school.
  ///
  /// In en, this message translates to:
  /// **'School'**
  String get school;

  /// No description provided for @teacher.
  ///
  /// In en, this message translates to:
  /// **'Teacher'**
  String get teacher;

  /// No description provided for @student.
  ///
  /// In en, this message translates to:
  /// **'Student'**
  String get student;

  /// No description provided for @students.
  ///
  /// In en, this message translates to:
  /// **'Students'**
  String get students;

  /// No description provided for @teachers.
  ///
  /// In en, this message translates to:
  /// **'Teachers'**
  String get teachers;

  /// No description provided for @teacher_newpost_alert.
  ///
  /// In en, this message translates to:
  /// **'added new post'**
  String get teacher_newpost_alert;

  /// No description provided for @your_email.
  ///
  /// In en, this message translates to:
  /// **'Your email'**
  String get your_email;

  /// No description provided for @comment________________________________________Registration_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Registration_____________________________________________;

  /// No description provided for @create_student.
  ///
  /// In en, this message translates to:
  /// **'Create A New Account'**
  String get create_student;

  /// No description provided for @register_new_school_title.
  ///
  /// In en, this message translates to:
  /// **'Register New School Account'**
  String get register_new_school_title;

  /// No description provided for @phone_number.
  ///
  /// In en, this message translates to:
  /// **'Phone number'**
  String get phone_number;

  /// No description provided for @city.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get city;

  /// No description provided for @country.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get country;

  /// No description provided for @register.
  ///
  /// In en, this message translates to:
  /// **'Register'**
  String get register;

  /// No description provided for @comment________________________________________Reset_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Reset_____________________________________________;

  /// No description provided for @reset_password.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get reset_password;

  /// No description provided for @submit.
  ///
  /// In en, this message translates to:
  /// **'Submit'**
  String get submit;

  /// No description provided for @reset_link_sent_title.
  ///
  /// In en, this message translates to:
  /// **'Reset Password link sent!'**
  String get reset_link_sent_title;

  /// No description provided for @reset_link_text.
  ///
  /// In en, this message translates to:
  /// **'Password reset link sent on your email'**
  String get reset_link_text;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'Okay'**
  String get ok;

  /// No description provided for @too_many_request.
  ///
  /// In en, this message translates to:
  /// **'You are trying too often. Please try again later'**
  String get too_many_request;

  /// No description provided for @operation_failed.
  ///
  /// In en, this message translates to:
  /// **'Operation failed. Try again later'**
  String get operation_failed;

  /// No description provided for @comment________________________________________Home_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Home_____________________________________________;

  /// No description provided for @home.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get home;

  /// No description provided for @classrooms.
  ///
  /// In en, this message translates to:
  /// **'Classrooms'**
  String get classrooms;

  /// No description provided for @no_class_joined_msg.
  ///
  /// In en, this message translates to:
  /// **'You have not joined any class!'**
  String get no_class_joined_msg;

  /// No description provided for @are_you_sure.
  ///
  /// In en, this message translates to:
  /// **'Are you sure?'**
  String get are_you_sure;

  /// No description provided for @logout_msg.
  ///
  /// In en, this message translates to:
  /// **'Do you want to logout?'**
  String get logout_msg;

  /// No description provided for @yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @comment________________________________________Student_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Student_____________________________________________;

  /// No description provided for @add_classroom.
  ///
  /// In en, this message translates to:
  /// **'Add classroom'**
  String get add_classroom;

  /// No description provided for @class_name.
  ///
  /// In en, this message translates to:
  /// **'Class name'**
  String get class_name;

  /// No description provided for @class_code.
  ///
  /// In en, this message translates to:
  /// **'Class code'**
  String get class_code;

  /// No description provided for @add.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// No description provided for @download.
  ///
  /// In en, this message translates to:
  /// **'Download'**
  String get download;

  /// No description provided for @comment________________________________________AdminSchool_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________AdminSchool_____________________________________________;

  /// No description provided for @add_teacher.
  ///
  /// In en, this message translates to:
  /// **'Add Teacher'**
  String get add_teacher;

  /// No description provided for @teacher_name.
  ///
  /// In en, this message translates to:
  /// **'Teacher name'**
  String get teacher_name;

  /// No description provided for @teacher_email.
  ///
  /// In en, this message translates to:
  /// **'Teacher email'**
  String get teacher_email;

  /// No description provided for @teacher_department.
  ///
  /// In en, this message translates to:
  /// **'Teacher department'**
  String get teacher_department;

  /// No description provided for @about_teacher.
  ///
  /// In en, this message translates to:
  /// **'About teacher'**
  String get about_teacher;

  /// No description provided for @member_since.
  ///
  /// In en, this message translates to:
  /// **'Member since'**
  String get member_since;

  /// No description provided for @teacher_added_title.
  ///
  /// In en, this message translates to:
  /// **'New Teacher Added'**
  String get teacher_added_title;

  /// No description provided for @teacher_added_text.
  ///
  /// In en, this message translates to:
  /// **'Kindly ask your teacher to check his email for Account credentials!'**
  String get teacher_added_text;

  /// No description provided for @comment________________________________________Post_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Post_____________________________________________;

  /// No description provided for @post_text.
  ///
  /// In en, this message translates to:
  /// **'Add your post here, it will be shared with your students!'**
  String get post_text;

  /// No description provided for @post_appbar_text.
  ///
  /// In en, this message translates to:
  /// **'Add New Post'**
  String get post_appbar_text;

  /// No description provided for @post.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get post;

  /// No description provided for @no_post_text.
  ///
  /// In en, this message translates to:
  /// **'No post added yet!'**
  String get no_post_text;

  /// No description provided for @postfield_labeltext.
  ///
  /// In en, this message translates to:
  /// **'Announce anything to your class!'**
  String get postfield_labeltext;

  /// No description provided for @post_published_title.
  ///
  /// In en, this message translates to:
  /// **'New Post published'**
  String get post_published_title;

  /// No description provided for @post_published_text.
  ///
  /// In en, this message translates to:
  /// **'Your post has been published successfully!'**
  String get post_published_text;

  /// No description provided for @comment________________________________________Class_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Class_____________________________________________;

  /// No description provided for @add_class_appbar.
  ///
  /// In en, this message translates to:
  /// **'Add New Class'**
  String get add_class_appbar;

  /// No description provided for @add_class_text.
  ///
  /// In en, this message translates to:
  /// **'Add your class here, and share Class Name and Code with your friends to join!'**
  String get add_class_text;

  /// No description provided for @description.
  ///
  /// In en, this message translates to:
  /// **'description'**
  String get description;

  /// No description provided for @class_added_title.
  ///
  /// In en, this message translates to:
  /// **'New Class Added'**
  String get class_added_title;

  /// No description provided for @class_added_text.
  ///
  /// In en, this message translates to:
  /// **'Kindly share Class name and Class code with your students to join!'**
  String get class_added_text;

  /// No description provided for @comment________________________________________Nofitications_____________________________________________.
  ///
  /// In en, this message translates to:
  /// **'*****************'**
  String get comment________________________________________Nofitications_____________________________________________;

  /// No description provided for @post_new_announcement_title.
  ///
  /// In en, this message translates to:
  /// **'posted new announcement in'**
  String get post_new_announcement_title;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
